using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cheas : Collectable
{

    public Sprite emptyCheas;
    public int pesosAmount = 10;


    protected override void OnCollect()
    {
        if (!collect)
        {
            collect = true;
            GetComponent<SpriteRenderer>().sprite = emptyCheas;

            GameManager.instance.ShowText(pesosAmount.ToString(), 15, Color.yellow, transform.position, Vector3.up * 50, 1.0f);
        }
    }
}
