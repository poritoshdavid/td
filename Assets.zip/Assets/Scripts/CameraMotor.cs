using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMotor : MonoBehaviour
{
    public Transform lookAt;

    public float boundX = 1.5f;
    public float boundY = 0.5f;


    // Update is called once per frame
    void LateUpdate()
    {
        Vector3 dalta = Vector3.zero;

        float deltX = lookAt.position.x - transform.position.x;
        if (deltX > boundX || deltX < -boundX)
        {
            if (transform.position.x < lookAt.position.x)
            {
                dalta.x = deltX - boundX;
            }
            else
            {
                dalta.x = boundX + deltX;
            }
        }
        float deltY = lookAt.position.y - transform.position.y;
        if (deltY > boundY || deltY < -boundY)
        {
            if (transform.position.y < lookAt.position.y)
            {
                dalta.y = deltY - boundY;
            }
            else
            {
                dalta.y = boundY + deltY;
            }
        }

        transform.position += new Vector3(dalta.x, dalta.y, 0);


    }
}
