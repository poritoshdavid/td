using System.Collections;
using System.Collections.Generic;

using UnityEngine;


public class Collectable : Colliable
{
    protected bool collect;

    protected override void OnCollid(Collider2D col)
    {
        if (col.name == "Player_0")
        {
            OnCollect();
        }

    }

    protected virtual void OnCollect()
    {
        collect = true;
    }
}