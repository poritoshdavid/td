using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FloatingTextManager : MonoBehaviour
{
    public GameObject textContainer;
    public GameObject textPref;

    List<FloatingText> floatingText = new List<FloatingText>();


    private void Update()
    {
        foreach (FloatingText item in floatingText)
        {
            item.UpdateFloatingText();
        }
    }


    public void Show(string msg, int fontSize, Color color, Vector3 position, Vector3 motion, float duration)
    {
        FloatingText fText = GetFloatingText();
        fText.text.text = msg;
        fText.text.fontSize = fontSize;
        fText.text.color = color;
        fText.text.transform.position = Camera.main.WorldToScreenPoint(position);
        fText.motion = motion;
        fText.duration = duration;
        fText.Show();
    }

    private FloatingText GetFloatingText()
    {
        FloatingText text = floatingText.Find(t => !t.active);

        if (text == null)
        {
            text = new FloatingText();
            text.go = Instantiate(textPref);
            text.go.transform.SetParent(textContainer.transform);
            text.text = text.go.GetComponent<Text>();
            floatingText.Add(text);
        }
        return text;
    }

}
