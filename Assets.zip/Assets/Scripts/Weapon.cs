using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : Colliable
{
    public int damagePoint = 1;
    public float pushForce = 2.0f;
    public int weaponLavel = 0;

    private SpriteRenderer spriteRenderer;

    private float coolDown = 0.5f;
    private float lastSwing;


    protected override void Start()
    {
        base.Start();
        spriteRenderer = GetComponent<SpriteRenderer>();

    }

    protected override void Update()
    {
        base.Update();
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (Time.time - lastSwing > coolDown)
            {
                lastSwing = Time.time;
                Swing();
            }

        }


    }

    protected override void OnCollid(Collider2D col)
    {

        if (col.tag == "Fighter")
        {

            if (col.name == "Player")
            {
                return;
            }

            Damage damage = new Damage
            {
                origin = transform.position,
                damageAmount = damagePoint,
                pushForce = pushForce,
            };

            //  col.SendMessage("RecievedMessage", damage);

            Debug.Log(col.name);
            Debug.Log("===========Weapon Script=============");
        }
    }

    private void Swing()
    {
        Debug.Log("Swing============");
    }


}
