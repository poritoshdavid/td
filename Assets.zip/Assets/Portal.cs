using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Portal : Colliable
{
    public string[] sceneNames;
    protected override void OnCollid(Collider2D col)
    {
        if (col.name == "Player_0")
        {
            string sceneName = sceneNames[Random.Range(0, sceneNames.Length)];
            SceneManager.LoadScene(sceneName);
            GameManager.instance.SaveState();
        }
    }

}
